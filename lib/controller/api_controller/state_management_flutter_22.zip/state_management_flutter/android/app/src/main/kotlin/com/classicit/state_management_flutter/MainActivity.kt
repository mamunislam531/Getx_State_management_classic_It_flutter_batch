package com.classicit.state_management_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
