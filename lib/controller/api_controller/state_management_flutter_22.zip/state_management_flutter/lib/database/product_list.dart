class ProductList {
  static Map<String, dynamic> productList = {
    "productList": [
      {"id": 1, "name": "Mouse", "price": 350, "image": ""},
      {"id": 2, "name": "Keyboard", "price": 450, "image": ""},
      {"id": 3, "name": "Monitor", "price": 5000, "image": ""},
      {"id": 4, "name": "Mouse", "price": 350, "image": ""},
      {"id": 5, "name": "Keyboard", "price": 450, "image": ""},
      {"id": 6, "name": "Monitor", "price": 5000, "image": ""},
    ]
  };
}
