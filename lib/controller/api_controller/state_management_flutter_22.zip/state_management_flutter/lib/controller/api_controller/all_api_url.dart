


class Apis{

  static String baseIP = "http://192.168.0.115:8000";
  static String signInUrl = "$baseIP/api/delivery-boy/login";
  static String signUpUrl = "$baseIP/api/delivery-boy/registration";
  static String dashboardUrl = "$baseIP/api/delivery-boy/dashboard";
}