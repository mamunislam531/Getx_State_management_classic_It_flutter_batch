

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:state_management_flutter/controller/api_controller/sign_in_service.dart';
import 'package:state_management_flutter/view/screen/home/home.dart';

class SignInController extends GetxController{
  final formKey = GlobalKey<FormState>();
  TextEditingController mailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  RxBool isLoading = false.obs;


  signInFun()async{
    isLoading.value = true;
    bool status = await SignInService.signIn(mail: mailController.text, password: passwordController.text);
    isLoading.value = false;

    if(status){
      log("Next Page");
      Get.to(()=> const Home());
      return;
    }
  }

  @override
  void dispose() {
    mailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

}