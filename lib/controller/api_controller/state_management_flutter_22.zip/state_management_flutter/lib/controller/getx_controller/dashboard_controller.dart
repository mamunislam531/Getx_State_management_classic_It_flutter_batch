import 'dart:developer';

import 'package:get/get.dart';
import 'package:state_management_flutter/controller/api_controller/dashboard_service.dart';
import 'package:state_management_flutter/model/dashboard_model.dart';

class DashboardController extends GetxController {
  DashboardData? dashboardData;
  RxBool isLoading = false.obs;

  getDashboardData() async {
    isLoading.value = true;
    dashboardData = await DashboardService.getData();
    isLoading.value = false;
  }

  @override
  void onInit() {
    getDashboardData();
    super.onInit();
  }
}
